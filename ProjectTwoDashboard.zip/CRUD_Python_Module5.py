# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, USER, PASS): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        #USER = 'aacuser' 
        #PASS = 'password' 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
            
    # Create new entry 
    def create( self, data ):
        if data is not None: 
            try:
                self.database.animals.insert_one( data ) # data should be dictionary
                return True
            except Exception as error:
                return False
           
        else: 
            raise Exception( "Nothing to save, because data parameter is empty" ) 

    # Read database
    def read( self, query ):
        try:
            queriedResults = self.database.animals.find( query )
            return list( queriedResults )
        except Exception as e:
            return []

    # Update entries
    def update( self, query, data ):
        try:
            result = self.database.animals.update_many( query, {"$set": data} )
            return result.modified_count
        except Exception as error:
            return 0
        
    # Delete entries
    def delete( self, query):
        try:
            result = self.database.animals.delete_many( query )
            return result.deleted_count
        except Exception as error:
            return 0